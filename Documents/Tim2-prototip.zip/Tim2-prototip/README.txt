Aplikacija se pokre�e klikom na "sistemZaEvidencijuStalnihSredstava.jar".

PDF fajlovi unutar foldera slu�e za prikaz izgleda generisanog izvje�taja unutar aplikacije.

